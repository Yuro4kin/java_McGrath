class Arithmetic                                 // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			 int num = 100 ;
			 int factor = 20 ;
			 int sum = 0 ;           

			 sum = num + factor ;
			 System.out.println ( "The result of addition: " + sum ) ; 		   // + sum   -  concatenation for get one string
			  
			 sum = num - factor ;
			 System.out.println ( "The result of subtraction: " + sum ) ; 		 

			 sum = num * factor ;
			 System.out.println ( "The result of multiplication: " + sum ) ;
			 
			 sum = num / factor ;
			 System.out.println ( "The result of division: " + sum ) ; 
			 
			 
			 int totalProfitA = 1000 ;
			 int profitJanuaryA = 1200;
			 int profitFebruaryA = 0 ;
			 profitFebruaryA = totalProfitA - profitJanuaryA ;
			 System.out.println ( "The total profit for a company _A_ two months: " + totalProfitA ) ; 
			 System.out.println ( "The profit for a company _A_ in January: " + profitJanuaryA ) ; 
			 System.out.println ( "The profit for a company _A_ in February: " + profitFebruaryA ) ; 

			 int totalProfitB = -100 ;
			 int profitJanuaryB = 800;
			 int profitFebruaryB = 0 ;
			 profitFebruaryB = totalProfitB - profitJanuaryB ;
			 System.out.println ( "The total profit for a company _B_ two months: " + totalProfitB ) ; 
			 System.out.println ( "The profit for a company _B_ in January: " + profitJanuaryB ) ; 
			 System.out.println ( "The profit for a company _B_ in February: " + profitFebruaryB ) ; 

			 // To subtract any number, it is enough to add the opposite number to the subtracted one. -(+a) = -a //  -(-a) = +a  //
			 int totalProfitAA = 1000 ;
			 int profitJanuaryAA = 1200;
			 int profitFebruaryAA = 0 ;
			 profitFebruaryAA = totalProfitAA + (- profitJanuaryAA) ;										//  (- profitJanuaryAA) 
			 System.out.println ( "The total profit for a company _AA_ two months: " + totalProfitAA ) ; 
			 System.out.println ( "The profit for a company _AA_ in January: " + profitJanuaryAA ) ; 
			 System.out.println ( "The profit for a company _AA_ in February: " + profitFebruaryAA ) ; 

			 // To subtract any number, it is enough to add the opposite number to the subtracted one. -(+a) = -a //  -(-a) = +a  //
			 int totalProfitAAA = 1000 ;
			 int profitJanuaryAAA = 1200;
			 int profitFebruaryAAA = 0 ;
			 int chengeJanuaryAAA = -1 ;
			 chengeJanuaryAAA = -1 * profitJanuaryAAA ;					
			 profitFebruaryAAA = (totalProfitAAA + chengeJanuaryAAA) ;
			 System.out.println ( "The total profit for a company _AAA_ two months: " + totalProfitAAA ) ; 
			 System.out.println ( "The profit for a company _AAA_ in January: " + profitJanuaryAAA ) ; 
			 System.out.println ( "The profit for a company _AAA_ in February: " + profitFebruaryAAA ) ; 
		}
}









