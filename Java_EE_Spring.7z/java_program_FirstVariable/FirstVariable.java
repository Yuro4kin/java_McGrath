class FirstVariable                             // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

        {										// (all program instructions inside curly braces)
			String message = "First value" ;   // creation, initialization and subsequent output of the variable 
			System.out.println( message ) ;				
			message = "Changed value" ;		   // the value of the variable is changed and displayed again:
			System.out.println( message ) ;				
		}
}









