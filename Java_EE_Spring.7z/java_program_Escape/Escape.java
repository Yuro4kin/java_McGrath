class Escape                                    // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			
			String quote = " \"Fortune favors the brave.\" \t \' Said Valeriy \' " ;
			System.out.println( "What you know about fortune: " + quote ) ;  

			String header = "\n\tNEW-YORK 3 DAYS FORECAST:\n" ;
			header += "\n\tDay\t\tMax\tMin\tPrecipitation\n" ;
			header += "\t---\t\t----\t---\t----------\n" ;

			String forecast = "\tSunday\t\t68F\t48F\tClear\n" ;
			forecast += "\tMonday\t\t69F\t57F\tClear\n" ;
			forecast += "\tThusday\t\t71F\t50F\tCloudly\n" ;

			System.out.print( header + forecast ) ;                                   // System.out.print () ;  - for print
		
		}
}









