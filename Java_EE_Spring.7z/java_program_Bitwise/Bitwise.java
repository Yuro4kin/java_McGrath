class Bitwise                                   // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			
			byte fs = 53 ;													//  53 = 00110101
			System.out.println("Flag 1: "+(( (fs&1)>0) ? "ON" : "off"));	//  1 x 1
			System.out.println("Flag 2: "+(( (fs&2)>0) ? "ON" : "off"));    //  0 x 2
			System.out.println("Flag 3: "+(( (fs&4)>0) ? "ON" : "off"));    //  1 x 4
			System.out.println("Flag 4: "+(( (fs&8)>0) ? "ON" : "off"));    //  0 x 8
			System.out.println("Flag 5: "+(( (fs&16)>0)? "ON" : "off"));    //  1 x 16
			System.out.println("Flag 6: "+(( (fs&32)>0)? "ON" : "off"));    //  1 x 32
			System.out.println("Flag 7: "+(( (fs&64)>0)? "ON" : "off"));    //  0 x 64
			System.out.println("Flag 8: "+(( (fs&128)>0)?"ON" : "off"));    //  0 x 128             // n << p Moves n bits p left
		}
}









