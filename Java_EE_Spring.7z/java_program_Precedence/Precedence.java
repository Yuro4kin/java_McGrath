class Precedence                                 // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			 int sum = 32 - 8 + 16 * 2 ;
			 System.out.println( "The order of the default actions: " + sum ) ;  
			 
			 int sum1 = (32 - 8 + 16) * 2 ;
			 System.out.println( "The specified procedure: " + sum1 ) ;  
			 
			 int sum2 = (32 - (8 + 16)) * 2 ;
             System.out.println( "Specific  procedure: " + sum2 ) ;  
		
		}
}









