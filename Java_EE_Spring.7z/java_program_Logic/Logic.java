class Logic                                 // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			 
			 
			 boolean yes = true ;
             boolean no = false ;
			      
			 System.out.println ( "The result of the expression YES and YES: " + (yes && yes) ) ;      //  true     //   && Logic and
			 System.out.println ( "The result of the expression YES and NO: " + (yes && no) ) ;        //  false    //   && Logic and

			 System.out.println ( "The result of the expression YES or YES: " + (yes || yes) ) ;      //   true    //   || Logic or // if at least one is true
			 System.out.println ( "The result of the expression YES or NO: " + (yes || no) ) ;        //   true    //   || Logic or // if at least one is true
			 System.out.println ( "The result of the expression YES or NO: " + (no || no) ) ;        //    false   //    || Logic or // if at least one is true
			
			 System.out.println ( "The initial value of the variable is YES: " + yes ) ;			 //    true  	//  opposite meaning
			 System.out.println ( "Inverted variable yes: " + !yes ) ;								//     false         opposite meaning


			 String air = "On the beach" ;
			 String water = "On the beach" ;
			 boolean condition = ( air == water ) ;  // Assignment result comparison      ==   true or false        
			 System.out.println ( "Checking Strings for Equality_boolean: " + condition ) ; 
			 condition = ( air != water ) ;          // Assignment result				!=  false
             System.out.println( "Checking Strings for inequality: " + condition ) ;  
             int temperatureMorningAir = 15 ;
             int temperatureEveningAir = 20 ;	 
			 condition = ( temperatureMorningAir > temperatureEveningAir ) ;		// Assignment result				15 > 20 - false  
			 System.out.println( "Checking integer for more temperature of the Azov Sea on Air: " + condition ) ; 


			 String airTown = "Odessa" ;
			 String waterTown = "Odessa" ;
			 boolean status = ( airTown == waterTown ) ;  // Assignment result comparison      ==   true or false        
			 System.out.println ( "Checking Strings for Equality_boolean: " + status ) ; 
			 status = ( airTown != waterTown ) ;          // Assignment result				!=  false
             System.out.println( "Checking Strings for inequality: " + status ) ;  
             int temperatureMorningAirTown = 18 ;
             int temperatureEveningAirTown = 20 ;
			 status = ( temperatureMorningAirTown < temperatureEveningAirTown ) ;		// Assignment result		18  < 20 - true   
			 System.out.println( "Checking integer for more temperature of the Azov Sea on Air: " + status ) ; 

			 System.out.println ( "The result of the boolean CONDITION and CONDITION: " + (condition && condition) ) ;    
			 System.out.println ( "The result of the expression STATUS and STATUS: " + (status && status) ) ; 
			 System.out.println ( "The result of the expression CONDITION and STATUS: " + (condition && status) ) ;       

		}
}









