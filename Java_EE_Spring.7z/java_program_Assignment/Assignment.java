class Assignment                                 // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			 
			 String txt = "Fantastic " ;
			 String lang = "Java" ;
			 txt += lang ;              // Assignment with rows combining   += // a += b // a = a + b
			 System.out.println ( "Ad and assign strings: " + txt ) ; 
			 
			 int sum = 10 ;
			 int num = 20 ;
			 sum += num ;              //  Assignment result ( 10 + 20 = 30 )  // += // a += b // a = a + b
			 System.out.println ( "Ad and assign integer numbers: " + sum ) ;

			 int factor = 5 ;
			 sum *= factor ;		   // Asignment result ( 30 x 5 = 150 )    // *= //  a *= b // a = a * b
			 System.out.println ( "Multiplication result: " + sum ) ;
			 
			 sum /= factor ;		   //  Assignment result ( 150 / 5 = 30 )  $   /=   $   a /= b   $   a = a / b
             System.out.println ( "Division result: " + sum ) ;
		}
}









