class Hello {     //  Between the curly brackets of the Hello class,
				  //  insert this code – to create a “main” method for the Hello class
	
	
	  public static void main( String [] args) {  //   Between the curly brackets of the main method, 
												  //   insert this line of code – stating what the program will do                                         

		System.out.println ("Hello World!") ;
	
	}
}


// hit the Enter key