
 class Else                                         //  Start a new program named _Else_ containing the standard main method
 
{													//  Between the curly brackets of the Else class,
	public static void main ( String[] args )       //  insert this code – to create a main _method_ for the Else class
												

		{										    // (all program instructions inside curly brackets)
			int hrs = 18 ;	                        // chenge the integer  // 16 or 18 
			int tmtre = 26 ;						// chenge the integer  // 24 or 26 					
			if (( hrs < 17 ) || ( tmtre < 25 )) {
							System.out.println ( "We should work until at : " + hrs + " p.m." ) ;		
							System.out.println ( "We ride a bysicle until: " + tmtre + " Celsium" ) ;
							              }							
											
			else if (( hrs > 16 ) || ( tmtre > 25 )) {
							System.out.println( "We go home at : " + hrs + " p.m" ) ; 
							System.out.println( "We ride a taxi: " + tmtre + " Celsium" ) ;
			                                         }
							 
							System.out.println( "~ n_e_w p_r_o_g_r_a_m ~ " ) ;

			int hours = 15 ;						 // chenge the integer  // 11 or 15 				 
			if ( hours < 13 ) {
				            System.out.println ( "Good morning : " + hours + " a.m." ) ;								        
							  }
			else if	( hours < 18 ) {
							System.out.println ( "Good day : " + hours + " p.m." ) ;
									}		
							
							System.out.println( "~ n_e_w p_r_o_g_r_a_m ~ " ) ;

			int cels = 17 ;						 // chenge the integer  // 17 or 23 				 
			if ( cels > 22 ) {
				            System.out.println ( "They go to swim : " + cels + " 0.C" ) ;								        
							  }
			else            System.out.println ( "They do not go to swim : " + cels + " 0.C"  ) ;          //  do not use -if- with -else-
		}
}









