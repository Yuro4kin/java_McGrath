class DataTypes                             // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
																	// Type recognition data
			char letter = 'M' ;   									// char Single Unicode character 'a'
			String title = "Java in easy steps" ;					// Any number of characters in unicode
			int number = 365 ;										// Integer in the range –2147483648 to 2147483647
			float decimal = 98.6f ;									// Floating real number point
			boolean result = false ;								// Boolean true or false

			System.out.println ( "Word " + letter ) ;
		    System.out.println ( "Name " + title ) ;
		    System.out.println ( "Amount of days " + number ) ;
		    System.out.println ( "Temperature " + decimal ) ;
		    System.out.println ( "Answer " + result ) ;	
		}		
}









