
 class If                                        //  Start a new program named _If_ containing the standard main method
 
{
	public static void main ( String[] args )   //  Between the curly brackets of the If class,
												//  insert this code – to create a main _method_ for the Hello class

		{										// (all program instructions inside curly braces)
												
			if ( 5 > 1 )
			  System.out.println ("Five is greater than one." ) ;									
			if ( 2 < 4 )
			            {
			              System.out.println( "Two is less than four ." ) ;
			              System.out.println( "Test succeeded." ) ;
						}
			int num = 8 ;
			if ( (( num > 5 ) && ( num < 10 )) || ( num == 12 ) )                    //  ( and &&) 
																					 // ( The Boolean || OR operator ensures a complex expression will only return true
																					 //  when either one of the tested conditions is true:)
						
		             	{
			              System.out.println( "Number is 6-9 inclusive, or 12" ) ;       // true
			              System.out.println( "Number : " + num ) ;                           // num = 8

						}
						
			int number = 10 ;
			if  (( number > 8 ) || ( number < 5 ))                     			 // ( The Boolean || OR operator ensures a complex expression will only return true
																					 //  when either one of the tested conditions is true:)	             	
			              System.out.println( "Boolean || OR - true,  when either one of the tested conditions is true 10 > 5 || 10 < 5 ") ;       
		}
}









