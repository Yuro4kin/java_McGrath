class Constants                                 // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
												// final - constant fixed values that should not change during execution programs
												// registr - final int TOUCHDOWN
			final int TOUCHDOWN = 6 ;			// Creating and initializing three integer constants // Scoring constants
			final int CONVERSION = 1 ;   
			final int FIELGOAL = 3 ;

			int td , pat, fg , total , dv ;			// Declare four integer variables // Scoring
			td = 4 * TOUCHDOWN ; 
			pat = 3 * CONVERSION ;
			fg = 2 * FIELGOAL ;
			total = ( td + pat + fg ) ;

			System.out.println ( "Total points: " + total ) ;  		//  Calculated sum output
		}
}









