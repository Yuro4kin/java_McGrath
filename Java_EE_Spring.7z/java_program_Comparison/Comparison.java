class Comparison                                 // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			 
			 String txt = "Fantastic " ;
			 String lang = "Java" ;
			 boolean state = ( txt == lang ) ;  // Assignment result comparison      ==   true or false        
			 System.out.println ( "Checking Strings for Equality: " + state ) ; 
			 
			 state = ( txt != lang ) ;          // Assignment result				!=  true
             System.out.println( "Checking Strings for inequality: " + state ) ;      
		


			 
			 int dozen = 12 ;
             int score = 20 ;
			 state = ( dozen > score ) ;		// Assignment result				12 > 20 - false  
			 System.out.println( "Checking integer for more: " + state ) ; 

			 state = ( dozen < score ) ;		// Assignment result				12 < 20 - true
			 System.out.println( "Checking integer for less: " + state ) ; 


		}
}









