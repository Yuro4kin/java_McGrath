class Condition                                 // The program name is declared after the class keyword, the program container        
{
	public static void main ( String[] args )   // standard code for defining the starting point for virtually all Java programs
                                                // a method named main is declared
                                                // main method of Hello class
                                                // public static void - prefixing the method name, define how the method should be used
                                                // String [] args - used when passing values ​​to the method

		{										// (all program instructions inside curly braces)
			 int num1 = 1357 ;
             int num2 = 2468 ;
			 String result ; 
			 
			 result = ( num1 % 2 != 0 ) ? "odd" : "even" ;
			 System.out.println( num1 + " - " + result ) ;
			 result = ( num2 % 2 != 0 ) ? "odd" : "even" ;
			 System.out.println( num2 + " - " + result ) ;

			 String title = "Java in easy steps" ;
			 String article = "About Java and easy steps" ;
			 boolean quit1 = true ;          
			 String results ; 
			 
			 results = ( quit1 == true ) ? "It is true" : "You can do it" ;
			 System.out.println( title + " - " + results ) ;
			 results = ( quit1 != true ) ? "It is true" : "You can do it" ;
			 System.out.println( article + " - " + results ) ;


			 int speed = 80 ;
			 int speedLimit = 60 ;
			 boolean busted ;
			 busted = ( speed > speedLimit ) ? true : false ;
			 System.out.println( speed + " - " + busted ) ;
			 busted = ( speed < speedLimit ) ? true : false ;
			 System.out.println( speed + " - " + busted ) ;

			 String scaleA = "Celsius" ;
			 String scaleB = "Celsius" ;
			 float bodyTemperature ;
			 float machineTemperature ;
			 bodyTemperature = ( scaleA != "Celsius" ) ? 98.6f : 37.0f ;
			 System.out.println( scaleA + " - " + bodyTemperature ) ;
			 machineTemperature = ( scaleB != "Kelvin" ) ? 37.0f : 98.6f ;      // add variable - list doesnt have
			 System.out.println( scaleB + " - " + machineTemperature ) ;

			 String weightA = "Lb" ;
			 String weightB = "Lb" ;
			 float bodyWeight ;
			 bodyWeight = ( weightA != "Lb" ) ? 93.5f : 74.0f ;
			 System.out.println( weightA + " - " + bodyWeight ) ;
			}
}









